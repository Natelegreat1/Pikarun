This assignment was written in C++ using the SDL.framework in Xcode on a Mac.

All Image files should be in the same directory.

Due to some weird errors, accessing wind speed X_Speed from Player or Pokeball causes a crash… therefore the call to the speed has been commented out and wind does not affect either.
The wind graphic should still appear.


Pressing a number on the keyboard will select the appropriate 'level' of difficulty to display (based on the questions in the specifications)

The perlin noise is implemented but does not display properly…

Random level generation is not completed though the fundamentals are present...


